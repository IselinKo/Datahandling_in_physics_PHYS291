
{

TCanvas* c500 = new TCanvas("c500","Drawing to the WEB",10,10,600,600);

   char * fnames[50];      //  we could have 50 images, this takes little space
   for(int k=0;k<50;k++) fnames[k]=new char[14];
   for(int k=0;k<50;k++) sprintf(fnames[k],"pict%d.png",k);

 
//     Preparing LATEX  - used below in the text part

TString latx="Coding the polynomial $f(x)$ into the TF1 and similar objects in ROOT\n";
latx=latx+"<br><br>\n";

latx=latx+"   $$  f(x) = p_0 + p_1 x + p_2 e^ {-p_3 ( x - p_4) ^2 }  $$ \n";
latx=latx+"<br><br>\n";


//     latex part end

   FILE *outfil;
   outfil=fopen("index.html","w");   //   opening   index.html   
   fprintf(outfil,"<html>\n");       //    starting HTML  printout    
   fprintf(outfil,"<head>\n");       //    head and title
   fprintf(outfil,"<title>\n");
   fprintf(outfil,"PHYS291 Project Spring 2026");
   fprintf(outfil,"</title>\n");

   fclose(outfil);                             // close - to insert mathJax

   system("cat mathjax.fil >>  index.html");

   outfil=fopen("index.html","a");      //  reopen index.html
   fprintf(outfil,"</head>\n");

   fprintf(outfil,"<body style=");  //  specify the font and colors
   
   fprintf(outfil,"\"font-family:monospace; font-size: 14pt; "); 
   fprintf(outfil," color:#000000; background-color:#cbddf5\"> \n");
   
   fprintf(outfil,"<br><b><big>Project PHYS291 - Iselin Kongsmark</big></b> \n");
   
   // Text width fixed by a TABLE TRICK 

   fprintf(outfil,"<br><table width=1100><tr><td style=");
   fprintf(outfil,"\"font-family:monospace; font-size: 14pt\"> \n");

   fprintf(outfil,"<br> In this project I visualize fMRI data representing brain activity in the Default Mode Network (DMN). The report consist of two main visualizations: one with constant time and varying spatial coordinates, and another with constant spatial coordinates and varying time.\n");
   fprintf(outfil, "<br><br>\n");
   
  fprintf(outfil, "<br><b>About the data and the preprocessing steps </b> \n");
  fprintf(outfil, "<br><br>\n");

  fprintf(outfil,"The raw data was stored in a NIfTI (.nii) file, with dimensions x, y, z, and t, forming voxels containing activity levels over time. The voxels have volume of 2 mm$^2$ and there are 0.72 seconds between each scan. \n");
  fprintf(outfil, "<br><br>\n");
  
  fprintf(outfil, "Using the Python package NiBabel, the data was be sampled and converted to a text file (CSV). Including every datap point would result in a the text file on ~GB magnitude, which would be excessive for this project. Sampling was therefore performed to reduce computational time and processing requirements while still retaining sufficient data quality for visualization purposes. Every other data point in x, y, and z axis was included, and the time axis was reduced to the first 42 time stamps, resulting in about 30 seconds of scans.\n");
  fprintf(outfil, "<br><br>\n");
  
  fprintf(outfil,"The text file was next converted into a ROOT file by using the TTree structure, which was beneficial for plotting in ROOT. \n");
  fprintf(outfil, "<br><br>\n");
  
  fprintf(outfil, "<br><b> Histograms at constant time </b> \n");
  fprintf(outfil, "<br><br>\n");
  
  fprintf(outfil,"This section presents two-dimensional histograms of brain slices generated in ROOT, where color represents activity level. x, y, and t coordinates remains constant, while z cordinate increases for each new plot. This creates the effect of scrolling through the brain volume, similar to the visualization used in CT imaging.\n");
  fprintf(outfil, "<br><br>\n");
  
//                           Making the graphics

   int I=0;
   TF1 *func;  TString FUNC;
   
//////// from plot_2Dhist.C

TFile *f = new TFile("fmri_val1_t42.root");
TTree *tree = (TTree*)f->Get("brain");
tree->Draw("intensity>>htemp", "", "goff");
TH1F *htemp = (TH1F*)gDirectory->Get("htemp");
Double_t mean = htemp->GetMean();

// call the function plot_2Dhist defined at bottom of script
plot_2Dhist(c500, tree, mean, 20, 0);
c500->Print(fnames[I]); 

plot_2Dhist(c500, tree, mean, 40, 0);
c500->Print(fnames[I+1]);

plot_2Dhist(c500, tree, mean, 60,0);
c500->Print(fnames[I+2]);

fprintf(outfil, "<div style=\"display:flex; gap:10px;\">\n");
fprintf(outfil, "<img src=\"%s\" style=\"width:32%%\">\n", fnames[I]);
fprintf(outfil, "<img src=\"%s\" style=\"width:32%%\">\n", fnames[I+1]);
fprintf(outfil, "<img src=\"%s\" style=\"width:32%%\">\n", fnames[I+2]);
fprintf(outfil, "</div>\n");
I += 3;

  fprintf(outfil,"<br>\n");
  fprintf(outfil,"The images shows brain cross sections at z = 20, 40 and 60 at time t=0. The colorbar indicates the absolute relative deviation from the mean activity level in the brain. Yellow zones are therefore either a much more active or much less active than the average voxel intensity. This is calculated using the following formula: \n");
  
  fprintf(outfil," $$  \\bar{I} = |\\frac{ I - \\text{Global mean}} {\\text{Global mean}} | \\cdot 100 $$\n");

fprintf(outfil,"To counteract sparse voxel density and create smoother plots, the intensity is averaged for nearby slices and ROOT's build in smooting function is utilized. \n");

fprintf(outfil,"In the images above, some areas are lit up more than the surrounding tissue. For future projects, it would be intersting to explore wether these areas match the regions one expect being active for this resting state network.\n");


// --- scroll through slices, save frames, make GIF ---
int frameCount = 0;
for (int slice = 0; slice < 78; slice += 2)
{
    plot_2Dhist(c500, tree, mean, slice, 0);
    c500->Print(Form("frame_%02d.png", frameCount));
    frameCount++;
}

system("convert -delay 20 -loop 0 frame_*.png scroll_animation.gif");
system("rm frame_*.png");  // clean up frames after GIF is made

fprintf(outfil, "<br><br>\n");
fprintf(outfil, "<br><b>Scrolling through all brain slices at t=0:</b><br>\n");
fprintf(outfil, "<img src=\"scroll_animation.gif\"><br>\n");
fprintf(outfil, "<br><br>\n");

// --- time evolution of slice, save frames, make GIF ---
int frameCount2 = 0;
for (int t = 0; t < 42; t++)
{
    plot_2Dhist(c500, tree, mean, 20, t);
    c500->Print(Form("frameA_%02d.png", t));

    plot_2Dhist(c500, tree, mean, 40, t);
    c500->Print(Form("frameB_%02d.png", t));

    plot_2Dhist(c500, tree, mean, 60, t);
    c500->Print(Form("frameC_%02d.png", t));

    // stitch the three side by side into one combined frame
    system(Form("convert frameA_%02d.png frameB_%02d.png frameC_%02d.png +append combined_%02d.png", t, t, t, t));
}
system("convert -delay 72 -loop 0 combined_*.png timeev_animation.gif");
system("rm frameA_*.png frameB_*.png frameC_*.png combined_*.png");

fprintf(outfil, "<br><br>\n");
fprintf(outfil, "<br><b>Time evolution of brain slices z=20, 40, 60:</b><br>\n");
fprintf(outfil, "<img src=\"timeev_animation.gif\" style=\"width:98%%\"><br>\n");
fprintf(outfil, "<br><br>\n");

//// ----------

   fprintf(outfil,"<a name=\"latexF\"> <br><hr><br> \n");

   fprintf(outfil,"  <b> More Latex examples </b> <br>");

   fprintf(outfil,"%s\n", latx.Data()); 

   fprintf(outfil,"</td></tr></table><br>\n");
 

  //  fprintf(outfil,"</body>\n");     // should be there
  //  fprintf(outfil,"</html>\n");      // but browsers are forgiving


   fprintf(outfil,"<b><br><a href=\"#latexF\"><big>More Latex examples</a></big> </b> below the graphics<br>");

   fclose(outfil);
   
   system("echo \"<br><br><b>The root macro root_to_webN.C producing all this </b>\" >> index.html");
   system("txtbox_white root_to_webN.C");
   system("cat root_to_webN.C.html >> index.html");
   system("txtbox_white about_html_2.txt");
   system("firefox  index.html  &");
   system("cp nswap swap");
   system("cp animate.fil animate.html");
   system("python3 -m http.server 8000 &");
   system("./swap &");
   sleep(1);
   system("firefox  http://127.0.0.1:8000/  &");
}

void plot_2Dhist(TCanvas* c, TTree* tree, Double_t mean, int slice = 40, int t = 0)
{
gStyle->SetPadLeftMargin(0.15);
c-> SetRightMargin(0.18);

// create histogram
tree->Draw(
    "y:x >> h(32,-10,100,32,-5,120)",
    Form("abs((intensity-%f)/%f) *(abs(z-%d)<2 && t==%d)", mean, mean, slice, t),
    "colz"
);

TH2F *h = (TH2F*)gDirectory->Get("h");

h->SetTitle(Form("Brain Slice z=%d   t=%d   (%.2f sec)", slice, t, t*0.72));
h->SetMinimum(0);
h->SetMaximum(1);

h->GetXaxis()->SetTitle("x");
h->GetYaxis()->SetTitle("y");
h->GetZaxis()->SetTitle("Intensity - Absolute Relative Deviation");

h->Smooth();
h->SetStats(0);
h->Draw("colz");}

