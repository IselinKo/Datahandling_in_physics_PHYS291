
alias lss='ls -ltrF'
alias cp='cp -i'
alias rm='rm -i'
alias mv='mv -i'
alias root='root -l'
alias root5='/scratch/root5 -l'
export HISTFILESIZE=6000
export HISTSIZE=6000
alias loc='source ~/bin/locale.matlab'
alias st='export TERM=xterm'
alias Pwd='pwd -P'
alias long='PS1="${debian_chroot:+($debian_chroot)}\u@\h:\w\$ "'
alias short='export PS1="\W/ "'
alias smiles='export PS1="😀\W 😀😍😍 "'
alias smile='export PS1="😀\w 😍 "'
alias shorter='export PS1=":-) "'
alias shortest='export PS1="-"'
alias tree='tree --charset=ascii'
export PATH=$PATH:~/bin
alias Num='export PS1="No.`cat /scratch/.no`: \W > "'
alias num='export PS1="No.`cat /scratch/.no`: \w > "'
alias dusk='du -s * | sort -n'
source /scratch/root/bin/thisroot.sh 

